
public class FortuneTellerViewer {
    public static void main(String[] args) {
        // Create and show the JFrame
        FortuneTellerFrame frame = new FortuneTellerFrame();
        frame.setVisible(true);
    }
}